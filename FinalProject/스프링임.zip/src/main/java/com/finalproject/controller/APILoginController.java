package com.finalproject.controller;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.SecureRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.finalproject.dto.UserDTO;
import com.finalproject.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@RestController
public class APILoginController {
    private final String CLIENT_ID = "UPdtA516wXiaIOb4sO8N";
    private final String CLIENT_SECRET_ID = "hPEIxHvQYy";
    
    @Autowired
    private UserService userService;
    
    @GetMapping("/naver")
    public void naverLogin(HttpSession session, HttpServletResponse response) throws IOException {
        String redirectURI = URLEncoder.encode("http://localhost:9999/naver/callback", "UTF-8");
        SecureRandom random = new SecureRandom();
        String state = new BigInteger(130, random).toString();
        String apiURL = "https://nid.naver.com/oauth2.0/authorize?response_type=code";
        apiURL += "&client_id=" + CLIENT_ID;
        apiURL += "&redirect_uri=" + redirectURI;
        apiURL += "&state=" + state;
        session.setAttribute("state", state);
        response.sendRedirect(apiURL);
    }

    @GetMapping("/naver/callback")
    public ResponseEntity<?> naverCallback(HttpSession session, @RequestParam String state, @RequestParam String code, HttpServletResponse response, HttpServletRequest request) throws IOException, JSONException {
        String redirectURI = URLEncoder.encode("http://localhost:9999/naver/callback", "UTF-8");
        String apiURL = "https://nid.naver.com/oauth2.0/token?grant_type=authorization_code&";
        apiURL += "client_id=" + CLIENT_ID;
        apiURL += "&client_secret=" + CLIENT_SECRET_ID;
        apiURL += "&redirect_uri=" + redirectURI;
        apiURL += "&code=" + code;
        apiURL += "&state=" + state;
        
        String res = requestNaverServer(apiURL, null);
        
        if (res != null && !res.equals("")) {
            JSONObject json = new JSONObject(res);
            String accessToken = json.getString("access_token");
            session.setAttribute("accessToken", accessToken);

            // 사용자 정보 요청
            String userInfo = requestNaverServer("https://openapi.naver.com/v1/nid/me", "Bearer " + accessToken);
            JSONObject userInfoJson = new JSONObject(userInfo).getJSONObject("response");
            
            // 필요한 사용자 정보
            String email = userInfoJson.getString("email");
            String nickname = userInfoJson.getString("nickname");
            String profileImage = userInfoJson.getString("profile_image");

            // 이미 가입된 사용자인지 확인하는 로직 추가 (DB 조회)
            UserDTO user = userService.getUserByEmail(email);

            if (user != null) {
                // 이미 회원인 경우 네이버 로그아웃 처리 후 세션에 사용자 정보를 저장하고 로그인 처리
                logoutNaver(session);
                session.invalidate();
                HttpSession newSession = request.getSession(true);
                newSession.setAttribute("user", user);
                return ResponseEntity.ok().body(user); // 로그인 성공 시 사용자 정보를 반환
            } else {
                // 회원가입 페이지로 이동하면서 사용자 정보를 쿼리 파라미터로 전달
                String redirectURL = String.format("http://localhost:3000/register?email=%s&nickname=%s&profileImage=%s",
                        URLEncoder.encode(email, "UTF-8"),
                        URLEncoder.encode(nickname, "UTF-8"),
                        URLEncoder.encode(profileImage, "UTF-8"));
                response.sendRedirect(redirectURL);
                logoutNaver(session); // 회원가입 페이지로 리디렉션 후 네이버 로그인 정보 삭제
                return ResponseEntity.status(HttpStatus.FOUND).build(); // 회원가입 페이지로 리디렉션
            }
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("로그인 실패");
        }
    }


    private void logoutNaver(HttpSession session) {
        String accessToken = (String) session.getAttribute("accessToken");
        if (accessToken != null) {
            String apiURL = "https://nid.naver.com/oauth2.0/token?grant_type=delete&";
            apiURL += "client_id=" + CLIENT_ID;
            apiURL += "&client_secret=" + CLIENT_SECRET_ID;
            apiURL += "&access_token=" + accessToken;
            apiURL += "&service_provider=NAVER";
            requestNaverServer(apiURL, null);
        }
    }

    private String requestNaverServer(String apiURL, String header) {
        StringBuffer res = new StringBuffer();
        try {
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            if (header != null && !header.equals("")) {
                con.setRequestProperty("Authorization", header);
            }

            int responseCode = con.getResponseCode();
            BufferedReader br;
            if (responseCode == 200) { // 정상 호출
                br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            } else { // 에러 발생
                br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            }
            String inputLine;
            while ((inputLine = br.readLine()) != null) {
                res.append(inputLine);
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res.toString();
    }
}