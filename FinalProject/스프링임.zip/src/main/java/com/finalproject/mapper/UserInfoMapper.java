package com.finalproject.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.finalproject.dto.UserDTO;

@Mapper
public interface UserInfoMapper {
	List<UserDTO> selectAllUser();

}
